#include <iostream>
#include <cmath>
#include <string>
using namespace std;

int main(int argc, char* argv[]) 
{
    if (argc != 4) 
    {
        cerr << "Usage: program_name lower_bound upper_bound step\n";
        return 1;
    }

    double lowerBound = stod(argv[1]);
    double upperBound = stod(argv[2]);
    double step = stod(argv[3]);

    for (double x = lowerBound; x <= upperBound; x += step) 
    {
        double result = (x + x*x + x*x*x)/cos(x);
        cout << "x = " << x << ", f(x) = " << result << endl;
    }

    cin >> step;

    return 0;
}
